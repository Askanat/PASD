# include "heap.hpp"


/* Nothing non TEMPLATE  -> EMPTY  */

